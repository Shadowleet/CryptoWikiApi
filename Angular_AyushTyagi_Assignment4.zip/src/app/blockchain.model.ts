export interface Blockchain {
    blockchainId: number;
    name: string;
    createdDate: Date;
    isDeleted: boolean;
  }